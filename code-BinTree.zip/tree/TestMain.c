#define _CRT_SECURE_NO_WARNINGS
#include"BinTree.h"

int main(void)
{
	char * str2 = "##B##CA";
	int index2 = 0;
	while (str2[index2] != '\0')
	{
		index2++;
	}
	index2 = index2 - 1;
	BinTree bc;
	BinTreeInit(&bc);
	bc.root = BinTreeCreatPostOrder(str2,&index2);
	BinTreePreOrder(bc.root);
	printf("\n");
	BinTreeInOrder(bc.root);
	printf("\n");
	BinTreePostOrder(bc.root);
	printf("\n");
	printf("===========\n");

	BinTree bt;
	BinTreeInit(&bt);
	char* str= "ABC#DE#F#####";
	int index = 0;
	bt.root = BinTreeCreatLevelOrder(str,&index);

	BinTreePreOrder(bt.root);
	printf("\n");
	BinTreeInOrder(bt.root);
	printf("\n");
	BinTreePostOrder(bt.root);
	printf("\n");
	printf("===========\n");

	BinTree t;
	t.root = Clone(bt);
	BinTreePreOrder(t.root);
	printf("\n");
	BinTreeInOrder(t.root);
	printf("\n");
	BinTreePostOrder(t.root);
	printf("\n");
	printf("===========\n");

	bool x;
	x = Equal(bc,t);
	if (x)
		printf("true\n");
	else
		printf("false\n");
	size_t h;
	h = Height(bt);
	printf("%d\n", h);
	size_t sz;
	sz = Size(t);
	printf("%d\n", sz);
	int lsz;
	lsz = LeafSize(bt);
	printf("Ҷ�ӽ�����Ϊ:%d\n", lsz);

	BinTreeNode* p;
	p = Find(bt, 'B');
	if (p != NULL)
	{
		printf("%c\n", p->data);
	}
	p = Parent(bt,p);
	if (p != NULL)
	{
		printf("%c\n", p->data);
	}
	else
	{
		printf("NULL\n");
	}
	printf("===========\n");

	char* str3 = "AB#DF###CE###";
	int index3 = 0;
	BinTree btp;
	BinTreeInit(&btp);
	//BinTreeCreatePreOrder_1(&btp);
	btp.root = BinTreeCreatPreOrder_3(str3, &index3);
	//btp.root = BinTreeCreatePreOrder_2();
	BinTreePreOrder(btp.root);
	printf("\n");
	BinTreeInOrder(btp.root);
	printf("\n");
	BinTreePostOrder(btp.root);
	printf("\n");
	printf("===========\n");

	int ksz = 0;
	ksz=KSize(bt, 4);
	printf("��k�������Ϊ:%d\n", ksz);

	int cp;
	cp = BinTreeComplete(bc);
	if (cp == 1)
		printf("��������ȫ��������\n");
	else
		printf("����������ȫ��������\n");
}