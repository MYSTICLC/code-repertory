#pragma once
#include "Common.h"
struct BinTreeNode;
#define QueueElemType struct BinTreeNode*

typedef  struct ListQueueNode
{
	QueueElemType data;
	struct ListQueueNode* next;
}ListQueueNode;

typedef struct ListQueue
{
	ListQueueNode* front;
	ListQueueNode* rear;
}ListQueue;

void ListQueueInit(ListQueue* pst);
void ListQueuePush(ListQueue* pst, QueueElemType val);
void ListQueuePop(ListQueue* pst);
QueueElemType ListQueueFront(ListQueue* pst);
QueueElemType ListQueueRear(ListQueue* pst);
void ListQueueShow(ListQueue* pst);
bool ListQueueEmpty(ListQueue* pst);
void ListQueueDestroy(ListQueue* pst);

void ListQueueInit(ListQueue* pst)
{
	pst->front = NULL;
	pst->rear = NULL;
}

bool ListQueueEmpty(ListQueue* pst)
{
	if (pst->front == NULL)
		return true;
	else
		return NULL;
}

void ListQueuePush(ListQueue* pst, QueueElemType val)
{
	ListQueueNode* s = (ListQueueNode*)malloc(sizeof(ListQueueNode));
	assert(s != NULL);
	s->data = val;
	s->next = NULL;

	if (pst->front == NULL)
	{
		pst->front = s;
		pst->rear = s;
	}
	else
	{
		pst->rear->next = s;
		pst->rear = s;
	}
}

void ListQueuePop(ListQueue* pst)
{
	ListQueueNode* p = pst->front;
	if (ListQueueEmpty(pst))
	{
		return;
	}
	else
	{
		pst->front = pst->front->next;
		free(p);
		p = pst->front;
	}
}

QueueElemType ListQueueFront(ListQueue* pst)
{
	if (ListQueueEmpty(pst))
	{
		return NULL;
	}
	return pst->front->data;
}

QueueElemType ListQueueRear(ListQueue* pst)
{
	if (ListQueueEmpty(pst))
	{
		printf("����Ϊ��!\n");
		return NULL;
	}
	return pst->rear->data;
}

void ListQueueShow(ListQueue* pst)
{
	ListQueueNode* p = NULL;
	if (ListQueueEmpty(pst))
	{
		printf("����Ϊ��!\n");
		return;
	}
	p = pst->front;
	while (p != NULL)
	{
		printf("%d ", p->data);
		p = p->next;
	}
	printf("\n");
}

void ListQueueDestroy(ListQueue* pst)
{
	ListQueueNode* p = pst->front;
	while (p != NULL)
	{
		pst->front = p->next;
		free(p);
		p = pst->front;
	}
	pst->front = pst->rear = NULL;
}