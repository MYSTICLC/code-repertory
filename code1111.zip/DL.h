#pragma once
#include"Common.h"
#define Elemtype int

typedef struct DListNode
{
	Elemtype data;
	struct DListNode* next;
	struct DListNode* prev;
}DListNode;

typedef DListNode* DList;
DListNode* _BuyNodeDL(Elemtype val);
void DListNodeInit(DList* plist);
void CreateDListNodeFront(DList* plist, Elemtype val);
void CreateDListNodeTail(DList* plist, Elemtype val);
void DListNodeShow(DList plist);
void DListNodePopFront(DList* plist);
void DListNodePopTail(DList* plist);
DListNode* DListNodeFind(DList pl, Elemtype val);
void DListNodeSort(DList* plist);
void DListNodeInsert(DList* plist, Elemtype val);
void DListNodeErase(DList* plist, Elemtype val);
void DListNodeReverse(DList* plist);
void DListNodeClear(DList* plist);
void DListNodeDestroy(DList* plist);

DListNode* _BuyNodeDL(Elemtype val)
{
	DListNode* s = (DListNode*)malloc(sizeof(DListNode));
	assert(s != NULL);
	s->data = val;
	s->prev = NULL;
	s->next = NULL;
	return s;
}

void DListNodeInit(DList* plist)
{
	*plist = NULL;
}

void CreateDListNodeFront(DList* plist, Elemtype val)
{
	DListNode* s = _BuyNodeDL(val);
	if (*plist == NULL)
		*plist = s;
	else
	{
		s->next = *plist;
		(*plist)->prev = s;
		*plist = s;
	}
}

void CreateDListNodeTail(DList* plist, Elemtype val)
{
	DListNode* s = _BuyNodeDL(val);
	DListNode* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		while (p->next != NULL)
		{
			p = p->next;
		}
		p->next = s;
		s->prev = p;
	}
}

void DListNodeShow(DList plist)
{
	DListNode* p = plist;
	while (p != NULL)
	{
		printf("%d->", p->data);
		p = p->next;
	}
	printf("over.\n");
}

void DListNodePopFront(DList* plist)
{
	DListNode* p = *plist;
	if (p == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	else
	{
		if (p->next == NULL)
		{
			*plist = NULL;
		}
		else
		{
			*plist = (*plist)->next;
			(*plist)->prev = NULL;
		}
		free(p);
	}
}

void DListNodePopTail(DList* plist)
{
	DListNode* p = *plist;
	if (p == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	else
	{
		while (p->next != NULL)
		{
			p = p->next;
		}
		if (p->prev == NULL)
		{
			*plist = NULL;
		}
		else
		{
			p->prev->next = NULL;
		}
		free(p);
	}
}

DListNode* DListNodeFind(DList pl, Elemtype val)
{
	DListNode* p = pl;
	if (p == NULL)
	{
		printf("����Ϊ��,����ʧ��!\n");
		return;
	}
	while (p != NULL && p->data != val)
	{
		p = p->next;
	}
	return p;
}

void DListNodeSort(DList* plist)
{
	DListNode* p = NULL;
	DListNode* q = NULL;
	DListNode* s = NULL;
	if (*plist == NULL || (*plist)->next == NULL)
		return;

	q = (*plist)->next;
	q->prev = NULL;
	(*plist)->next = NULL;
	while (q != NULL)
	{
		if (q->data < (*plist)->data)
		{
			s = q;
			q = q->next;
			s->next = *plist;
			(*plist)->prev = s;
			*plist = s;
			if (q != NULL)
			{
				q->prev = NULL;
			}
		}
		else
		{
			p = *plist;
			while (p->next != NULL && q->data >= p->next->data)
				p = p->next;
			s = q;
			q = q->next;
			if (p->next == NULL)
			{
				p->next = s;
				s->prev = p;
				s->next = NULL;
			}
			else
			{
				s->next = p->next;
				s->prev = p;
				p->next = s;
				s->next->prev = s;
			}

			if (q != NULL)
			{
				q->prev = NULL;
			}
			p = *plist;
		}
	}
}

void DListNodeInsert(DList* plist, Elemtype val)
{
	DListNode* s = _BuyNodeDL(val);
	DListNode* p = NULL;
	DListNodeSort(&(*plist));
	if (*plist == NULL)
	{
		*plist = s;
		return;
	}
	else
	{
		if (s->data < (*plist)->data)
		{
			s->next = (*plist);
			(*plist)->prev = s;
			*plist = s;
		}
		else
		{
			p = *plist;
			while (p->next != NULL && s->data >= p->next->data)
				p = p->next;
			if (p->next == NULL)
			{
				p->next = s;
				s->prev = p;
			}
			else
			{
				s->next = p->next;
				s->prev = p;
				p->next = s;
				s->next->prev = s;
			}
			s = NULL;
			p = NULL;
		}
	}
}

void DListNodeErase(DList* plist, Elemtype val)
{
	DListNode* p = *plist;
	if (*plist == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	while (p != NULL && p->data != val)
		p = p->next;
	if (p->prev == NULL)
	{
		if (p->next == NULL)
		{
			*plist = NULL;
		}
		else
		{
			p->next->prev = NULL;
			*plist = p->next;
		}
	}
	else
	{
		if (p == NULL)
		{
			printf("%d���ڸ������У�����ʧ�ܣ�\n", val);
			return;
		}
		else
		{
			if (p->next == NULL)
			{
				p->prev->next = p->next;
			}
			else
			{
				p->next->prev = p->prev;
				p->prev->next = p->next;
			}
		}
	}
	free(p);
}

void DListNodeReverse(DList* plist)
{
	DListNode* q = NULL;
	if (*plist == NULL || (*plist)->next==NULL)
		return;
	q = (*plist)->next;
	q->prev = NULL;
	(*plist)->next = NULL;
	while (q->next != NULL)
	{
		q = q->next;
		q->prev->next = *plist;
		(*plist)->prev = q->prev;
		*plist = q->prev;
		q->prev = NULL;
	}//�����������һ�����
	q->next = *plist;
	(*plist)->prev = q;
	*plist = (*plist)->prev;
}

void DListNodeClear(DList* plist)
{
	DListNode* p = NULL;
	while (*plist != NULL && (*plist)->next!=NULL)
	{
		p = *plist;
		*plist = (*plist)->next;
     	(*plist)->prev = NULL;
		free(p);
	}
	p = *plist;
	*plist = NULL;
	free(p);
}

void DListNodeDestroy(DList* plist)
{
	DListNodeClear(&(*plist));
}