#pragma once
#include"Common.h"
#define Elemtype int
//ͷ�� β�� ͷɾ βɾ ���� ��ֵ��ѯ ��ֵ���� ���� ��ӡ ��ֵɾ�� �ݻ� ���� ���
typedef struct ListNodeNH {
	Elemtype data;
	struct ListNodeNH* next;
}ListNodeNH;
typedef ListNodeNH* SListNH;
ListNodeNH* _BuyNodeLLNH(Elemtype val);
void SLNHInit(SListNH* plist);
void CreateSLNHFront(SListNH* plist, Elemtype val);
void CreateSLNHTail(SListNH* plist, Elemtype val);
void SLNHShow(SListNH plist);
void SLNHPopFront(SListNH* plist);
void SLNHPopTail(SListNH* plist);
ListNodeNH* SLNHFind(SListNH pl, Elemtype val);
void SLNHSort(SListNH* plist);
void SLNHInsert(SListNH *plist, Elemtype val);
void SLNHErase(SListNH *plist, Elemtype val);
void SLNHReverse(SListNH* plist);
void SLNHClear(SListNH* plist);
void SLNHDestroy(SListNH* plist);

void SLNHInit(SListNH* plist)
{
	*plist = NULL;
}

ListNodeNH* _BuyNodeLLNH(Elemtype val)
{
	ListNodeNH* s = (ListNodeNH*)malloc(sizeof(ListNodeNH));
	assert(s != NULL);
	s->data = val;
	s->next = NULL;
	return s;
}

void CreateSLNHFront(SListNH* plist, Elemtype val)
{
	ListNodeNH* s = _BuyNodeLLNH(val);
	if (*plist == NULL)
		*plist = s;
	else
	{
		s->next = *plist;
		*plist = s;
	}
}

void CreateSLNHTail(SListNH* plist, Elemtype val)
{
	ListNodeNH* s = _BuyNodeLLNH(val);
	ListNodeNH* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		while (p->next != NULL)
			p = p->next;
		p->next = s;
	}
}

void SLNHShow(SListNH plist)
{
	ListNodeNH* p = plist;
	while (p != NULL)
	{
		printf("%d->", p->data);
		p = p->next;
	}
	printf("over.\n");
}

void SLNHPopFront(SListNH* plist)
{
	ListNodeNH* p = *plist;
	if (*plist == NULL)
	{
		printf("������Ϊ�գ�����ɾ��!\n");
		return;
	}
	else if ((*plist)->next == NULL)
	{
		free(*plist);
		*plist = NULL;
	}
	else
	{
		*plist = (*plist)->next;
		free(p);
		p == NULL;
	}
}

void SLNHPopTail(SListNH* plist)
{
	ListNodeNH* p = *plist;
	ListNodeNH* prev = NULL;
	if (*plist == NULL)
	{
		printf("������Ϊ�գ�����ɾ��!\n");
		return;
	}
	else
	{
		while (p->next != NULL)
		{
			prev = p;
			p = p->next;
		}
		if (prev == NULL)
		{
			*plist = NULL;
		}
		else
		{
			prev->next = NULL;
		}
		free(p);
		p = NULL;
		prev = NULL;
	}
}

ListNodeNH* SLNHFind(SListNH pl, Elemtype val)
{
	ListNodeNH* p = pl;
	if (pl == NULL)
	{
		printf("����Ϊ�գ�����ʧ��!\n");
		return;
	}
	while (p != NULL && p->data != val)
		p = p->next;
	return p;
}

void SLNHSort(SListNH* plist)
{
	ListNodeNH* p = NULL;
	ListNodeNH* q = NULL;
	ListNodeNH* s = NULL;
	if (*plist == NULL || (*plist)->next == NULL)
		return;
	q = (*plist)->next;
	(*plist)->next = NULL;
	while (q != NULL)
	{
		if (q->data < (*plist)->data)  //Ҳ�൱�ڸ�һ��ʼ��p���бȽ�
		{
			s = q;
			q = q->next;
			s->next = *plist;
			*plist = s;
			s = NULL;
		}
		else
		{
			p = *plist;  //��pָ�����������ĵ�һ�����
			while (p->next != NULL && q->data >= p->next->data)
				p = p->next;
			s = q;
			q = q->next;
			s->next = p->next;
			p->next = s;
			
			s = NULL;
			p = *plist;
		}
	}
}

void SLNHInsert(SListNH * plist, Elemtype val)
{
	ListNodeNH* s = _BuyNodeLLNH(val);
	ListNodeNH* p = NULL;
	SLNHSort(&(*plist));
	if (*plist == NULL)
	{
		*plist = s;
		return;
	}
	else
	{
		if (s->data < (*plist)->data)
		{
			s->next = *plist;
			*plist = s;
		}
		else
		{
			p = *plist;
			while (p->next != NULL && s->data >= p->next->data)
				p = p->next;
			s->next = p->next;
			p->next = s;

			s = NULL;
			p = NULL;
		}
	}
}

void SLNHErase(SListNH*plist , Elemtype val)
{
	ListNodeNH* p = *plist;
	ListNodeNH* prev = NULL;
	if (*plist == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ��!\n");
		return;
	}
	while (p != NULL && p->data != val)
	{
		prev = p;
		p = p->next;
	}
	if (prev == NULL)//��һ��������Ҫɾ���Ľ��
	{
		*plist = p->next;
	}
	else
	{
		if (p == NULL)
		{
			printf("������û��ֵΪ%d�Ľ�㣬ɾ��ʧ��!\n", val);
			return;
		}
		else
		{
			prev->next = p->next;
		}
	}
	free(p);
}

void SLNHReverse(SListNH* plist)
{
	ListNodeNH* p = NULL;
	ListNodeNH* q = NULL;
	if (*plist == NULL || (*plist)->next == NULL)
		return;
	q = (*plist)->next;
	(*plist)->next = NULL;
	while (q != NULL)
	{
		p = q;
		q = q->next;
		p->next = (*plist);
		(*plist) = p;
	}
}

void SLNHClear(SListNH* plist)
{
	ListNodeNH* p = NULL;
	while (*plist!=NULL)
	{
		p = *plist;
		*plist = (*plist)->next;
		free(p);
	}
}

void SLNHDestroy(SListNH* plist)
{
	SLNHClear(&(*plist));
}