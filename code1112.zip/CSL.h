#pragma once
#include"Common.h"
#define Elemtype int

typedef struct CSListNode
{
	Elemtype data;
	struct CSListNode* next;
}CSListNode;

typedef CSListNode* CSList;

CSListNode* _BuyNodeCSL(Elemtype val);
void CSListNodeInit(CSList* plist);
void CreateCSListNodeFront(CSList* plist, Elemtype val);
void CreateCSListNodeTail(CSList* plist, Elemtype val);
void CSListNodeShow(CSList plist);
void CSListNodePopFront(CSList* plist);
void CSListNodePopTail(CSList* plist);
CSListNode* CSListNodeFind(CSList pl, Elemtype val);
void CSListNodeSort(CSList* plist);
void CSListNodeInsert(CSList* plist, Elemtype val);
void CSListNodeErase(CSList* plist, Elemtype val);
void CSListNodeReverse(CSList* plist);
void CSListNodeClear(CSList* plist);
void CSListNodeDestroy(CSList* plist);

CSListNode* _BuyNodeCSL(Elemtype val)
{
	CSListNode* s = (CSListNode*)malloc(sizeof(CSListNode));
	assert(s != NULL);
	s->data = val;
	s->next = s;
}

void CSListNodeInit(CSList* plist)
{
	*plist = NULL;
}

void CreateCSListNodeFront(CSList* plist, Elemtype val)
{
	CSListNode* s = _BuyNodeCSL(val);
	CSListNode* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		while (p->next != *plist)
		{
			p = p->next;
		}
		s->next = *plist;
		p->next = s;
		*plist = s;
	}
}

void CreateCSListNodeTail(CSList* plist, Elemtype val)
{
	CSListNode* s = _BuyNodeCSL(val);
	CSListNode* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		while (p->next != *plist)
		{
			p = p->next;
		}
		p->next = s;
		s->next = *plist;
	}
}

void CSListNodeShow(CSList pl)
{
	CSListNode * p = pl;
	if (p != NULL)
	{
		while (p->next != pl)
		{
			printf("%d->", p->data);
			p = p->next;
		}
		printf("%d->", p->data);
	}
	printf("over.\n");
}

void CSListNodePopFront(CSList* plist)
{
	CSListNode* p = *plist;
	CSListNode* s = *plist;
	if (p == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	else
	{
		if (p->next == *plist)
		{
			*plist = NULL;
		}
		else
		{
			while (p->next != *plist)
				p = p->next;
			s = *plist;
			*plist = (*plist)->next;
			p->next = *plist;
			free(s);
		}
	}
}

void CSListNodePopTail(CSList* plist)
{
	CSListNode* p = *plist;
	CSListNode* prev = NULL;
	if (p == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	else
	{
		if (p->next == *plist)
		{
			*plist = NULL;
		}
		else
		{
			while (p->next != *plist)
			{
				prev = p;
				p = p->next;
			}
			prev->next = *plist;
			free(p);
		}
	}
}

CSListNode* CSListNodeFind(CSList pl, Elemtype val)
{
	CSListNode* p = pl;
	if (p == NULL)
	{
		printf("����Ϊ��,����ʧ��!\n");
		return;
	}
	else
	{
		while (p->next != pl && p->data != val)
			p = p->next;
		if (p->next == pl)
		{
			if (p->data == val)
				return p;
			else
				return NULL;
		}
		else
		{
			return p;
		}
	}
}

void CSListNodeSort(CSList* plist)
{
	CSListNode* p = NULL;
	CSListNode* q = NULL;
	CSListNode* s = NULL;
	if (*plist == NULL || (*plist)->next == *plist)
		return;
	p = *plist;
	q = p->next;
	while (q->next != *plist)
		q = q->next;
	q->next = NULL;
	q = p->next;
	p->next = *plist;
	while (q->next != NULL)
	{
		if (q->data < (*plist)->data)
		{
			s = q;
			q = q->next;
			while (p->next != *plist)
				p = p->next;
			s->next = *plist;
			p->next = s;
			*plist = s;
			
			p = *plist;
			s = NULL;
		}
		else
		{
			s = q;
			q = q->next;
			while (p->next != *plist && s->data >= p->next->data)
				p = p->next;
			if (p->next == *plist)
			{
				p->next = s;
				s->next = *plist;
			}
			else
			{
				s->next = p->next;
				p->next = s;
			}
			p = *plist;
			s = NULL;
		}
	}
	if (q->data < (*plist)->data)
	{
		while (p->next != *plist)
			p = p->next;
		q->next = *plist;
		p->next = q;
		*plist = q;

		p = *plist;
	}
	else
	{
		while (p->next != *plist && q->data >= p->next->data)
			p = p->next;
		if (p->next == *plist)
		{
			p->next = q;
			q->next = *plist;
		}
		else
		{
			q->next = p->next;
			p->next = q;
		}
		p = *plist;
	}
}

void CSListNodeInsert(CSList* plist, Elemtype val)
{
	CSListNode* p = NULL;
	CSListNode* s = _BuyNodeCSL(val);
	CSListNodeSort(&(*plist));
	if (*plist == NULL)
		*plist = s;
	p = *plist;
	if (s->data < (*plist)->data)
	{
		while (p->next != *plist)
			p = p->next;
		s->next = *plist;
		p->next = s;
		*plist = s;
	}
	else
	{
		while (p->next != *plist && s->data >= p->next->data)
			p = p->next;
		if (p->next == *plist)
		{
			p->next = s;
			s->next = *plist;
		}
		else
		{
			s->next = p->next;
			p->next = s;
		}
	}
}

void CSListNodeErase(CSList* plist, Elemtype val)
{
	CSListNode* p = *plist;
	CSListNode* prev = NULL;
	CSListNode* s = NULL;
	if (*plist == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		while (p->next != *plist && p->data != val)
		{
			prev = p;
			p = p->next;
		}
		if (p->next == *plist)
		{
			if (p->data == val && prev==NULL)
			{
				*plist = NULL;
			}
			else if (p->data == val && prev != NULL)
			{
				prev->next = *plist;
			}
			else
			{
				printf("%d���ڸ������У�ɾ��ʧ�ܣ�\n",val);
				return;
			}
		}
		else
		{
			if (prev == NULL)
			{
				s = *plist;
				while (s->next != *plist)
					s = s->next;
				*plist = p->next;
				s->next = *plist;
			}
			else
			{
				prev->next = p->next;
			}
		}
		free(p);
	}
}

void CSListNodeReverse(CSList* plist)
{
	CSListNode* p = NULL;
	CSListNode* q = NULL;
	CSListNode* s = NULL;
	if (*plist == NULL || (*plist)->next == *plist)
		return;
	p = *plist;
	q = p->next;
	while (q->next != *plist)
		q = q->next;
	q->next = NULL;
	q = p->next;
	p->next = *plist;
	while (q->next != NULL)
	{
		s = q;
		q = q->next;
		while (p->next != *plist)
			p = p->next;
		s->next = *plist;
		p->next = s;
		*plist = s;

		p = *plist;
		s = NULL;
	}
	while (p->next != *plist)
		p = p->next;
	q->next = *plist;
	p->next = q;
	*plist = q;
}

void CSListNodeClear(CSList* plist)
{
	CSListNode* p = NULL;
	CSListNode* r = *plist;
	if (*plist == NULL)
		return;
	while ((*plist)->next != *plist)
	{
		while (r->next != *plist)
			r = r->next;
		p = *plist;
		*plist = (*plist)->next;
		r->next = *plist;
		free(p);
	}
	p = *plist;
	*plist = NULL;
	free(p);
}

void CSListNodeDestroy(CSList* plist)
{
	CSListNodeClear(&(*plist));
}