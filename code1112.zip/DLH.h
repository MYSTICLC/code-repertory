#pragma once
#include"Common.h"
#define Elemtype int

typedef struct DHListNode
{
	Elemtype data;
	struct DHListNode* prev;
	struct DHListNode* next;
}DHListNode;

typedef struct DHList
{
	struct DHListNode* head;//ԭ����һ��ָ��
}DHList;

DHListNode* _BuyNodeDHL(Elemtype val);
void DHListNodeInit(DHList * plist);
void CreateDHListNodeFront(DHList* plist, Elemtype val);
void CreateDHListNodeTail(DHList* plist, Elemtype val);
void DHListNodeShow(DHList plist);
void DHListNodePopFront(DHList* plist);
void DHListNodePopTail(DHList* plist);
DHListNode* DHListNodeFind(DHList pl, Elemtype val);
void DHListNodeSort(DHList* plist);
void DHListNodeInsert(DHList* plist, Elemtype val);
void DHListNodeErase(DHList* plist, Elemtype val);
void DHListNodeReverse(DHList* plist);
void DHListNodeClear(DHList* plist);
void DHListNodeDestroy(DHList* plist);


DHListNode* _BuyNodeDHL(Elemtype val)
{
	DHListNode* s = (DHListNode*)malloc(sizeof(DHListNode));
	assert(s != NULL);
	s->data = val;
	s->prev = NULL;
	s->next = NULL;
	return s;
}

void DHListNodeInit(DHList* plist)
{
	plist->head = (DHListNode*)malloc(sizeof(DHListNode));
	assert(plist->head != NULL);
	plist->head->next = NULL;
	plist->head->prev = NULL;
}

void CreateDHListNodeFront(DHList* plist, Elemtype val)
{
	DHListNode* s = _BuyNodeDHL(val);
	DHListNode* p = plist->head;
	if (p->next == NULL)
	{
		p->next = s;
		s->prev = p;
	}
	else
	{
		s->prev = p;
		s->next = p->next;
		p->next->prev = s;
        p->next = s;
	}
}

void CreateDHListNodeTail(DHList* plist, Elemtype val)
{
	DHListNode* s = _BuyNodeDHL(val);
	DHListNode* p = plist->head;//���ָ��plist->head->next ,�����޸�p=s,��ֻ�ǽ�pָ��s����ͷָ��ָ��s;
	if (p->next == NULL)
	{
		p->next = s;
		s->prev = p;
	}
	else
	{
		while (p->next!= NULL)
		{
			p = p->next;
		}
		p->next = s;
		s->prev = p;
	}
}

void DHListNodeShow(DHList pl)
{
	DHListNode* p = pl.head->next;//ָ��ͷ���ָ��ĵ�һ�����ĵ�ַ
	while (p != NULL)
	{
		printf("%d->", p->data);
		p = p->next;
	}
	printf("over.\n");
}

void DHListNodePopFront(DHList* plist)
{
	DHListNode* p = plist->head;
	if (p->next == NULL)
	{
		printf("����Ϊ��,ɾ��ʧ��!\n");
		return;
	}
	else
	{ 
		p = p->next;
		if (p->next == NULL)
		{
			plist->head->next = NULL;
		}
		else
		{
			plist->head->next = p->next;
			p->next->prev = plist->head;
		}
		free(p);
	}
}
void DHListNodePopTail(DHList* plist)
{
	DHListNode* p = plist->head->next;
	if (p == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ��!\n");
		return;
	}
	else
	{
		while (p->next != NULL)
			p = p->next;
		p->prev->next = NULL;
		free(p);
	}
}

DHListNode* DHListNodeFind(DHList pl, Elemtype val)
{
	DHListNode* p = pl.head->next;
	if (p == NULL)
	{
		printf("����Ϊ��,����ʧ��!\n");
		return;
	}
	else
	{
		while (p != NULL && p->data != val)
			p = p->next;
		return p;
	}
}

void DHListNodeSort(DHList* plist)
{
	DHListNode* p = NULL;
	DHListNode* q = NULL;
	DHListNode* s = NULL;
	if (plist->head->next == NULL || plist->head->next->next == NULL)
		return;
	p = plist->head->next;
	q = p->next;
	p->next = NULL;
	while (q != NULL)
	{
		if (q->data < p->data)
		{
			s = q;
			q = q->next;
			s->next = p;
			s->prev = plist->head;
			p->prev = s;
			plist->head->next = s;
			if (q != NULL)
				q->prev = NULL;

			p = plist->head->next;
			s = NULL;
		}
		else
		{
			while (p->next != NULL && q->data >= p->next->data)
				p = p->next;
			s = q;
			q = q->next;
			if (p->next == NULL)
			{
				p->next = s;
				s->prev = p;
				s->next = NULL;
			}
			else
			{
				s->next = p->next;
				s->prev = p;
				p->next = s;
				s->next->prev = s;
			}
			if (q != NULL)
			{
				q->prev = NULL;
			}
			p = plist->head->next;
		}
	}
}

void DHListNodeReverse(DHList* plist)
{
	DHListNode* p = plist->head->next;
	DHListNode* q = NULL;
	DHListNode* s = NULL;
	if (p == NULL || p->next == NULL)
		return;
	q = p->next;
	p->next = NULL;
	while (q != NULL)
	{
		s = q;
		q = q->next;
		s->next = p;
		s->prev = plist->head;
		p->prev = s;
		plist->head->next = s;

		if (q != NULL)
			q->prev = NULL;
		s = NULL;
		p = plist->head->next;
	}
}

void DHListNodeInsert(DHList* plist, Elemtype val)
{
	DHListNode* p = plist->head;
	DHListNode* s = _BuyNodeDHL(val);
	DHListNodeSort(&(*plist));
	if (p->next == NULL)
	{
		p->next = s;
		s->prev = p;
	}
	else
	{
		p = plist->head->next;
		if (s->data < p->data)
		{
			s->next = p;
			s->prev = plist->head;
			plist->head->next = s;
			s->next->prev = s;

			p = plist->head->next;
			s = NULL;
		}
		else
		{
			while (p->next != NULL && s->data >= p->next->data)
				p = p->next;
			if (p->next == NULL)
			{
				s->prev = p;
				p->next = s;
			}
			else
			{
				s->next = p->next;
				s->prev = p;
				p->next = s;
				s->next->prev = s;
			}
			p = NULL;
			s = NULL;
		}
	}
}

void DHListNodeErase(DHList* plist, Elemtype val)
{
	DHListNode* p = plist->head->next;
	if (p == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ��!\n");
		return;
	}
	else
	{
		while (p != NULL && p->data != val)
			p = p->next;
		if (p == NULL)
		{
			printf("ɾ��ʧ��,%d����������!\n", val);
			return;
		}
		else
		{
			if (p->next == NULL)
			{
				p->prev->next = NULL;
			}
			else
			{
				p->prev->next = p->next;
				p->next->prev = p->prev;
			}
			free(p);
		}
	}
}

void DHListNodeClear(DHList* plist)
{
	DHListNode* p = NULL;
	while (plist->head->next!=NULL)
	{
		p = plist->head->next;
		plist->head->next = p->next;
		free(p);
	}
}

void DHListNodeDestroy(DHList* plist)
{
	DHListNode* p = plist->head;
	DHListNode* s = NULL;
	while (p != NULL)
	{
		s = p;
		p = p->next;
		free(s);
	}
}