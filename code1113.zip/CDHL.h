#pragma once
#include"Common.h"
#define Elemtype int

typedef struct CDHListNode
{
	Elemtype data;
	struct CDHListNode* prev;
	struct CDHListNode* next;
}CDHListNode;

typedef struct CDHList
{
	struct CDHListNode* head;
}CDHList;

CDHListNode* _BuyNodeCDHL(Elemtype val);
void CDHListNodeInit(CDHList* plist);
void CreateCDHListNodeFront(CDHList* plist, Elemtype val);
void CreateCDHListNodeTail(CDHList* plist, Elemtype val);
void CDHListNodeShow(CDHList plist);
void CDHListNodePopFront(CDHList* plist);
void CDHListNodePopTail(CDHList* plist);
CDHListNode* CDHListNodeFind(CDHList pl, Elemtype val);
void CDHListNodeSort(CDHList* plist);
void CDHListNodeInsert(CDHList* plist, Elemtype val);
void CDHListNodeErase(CDHList* plist, Elemtype val);
void CDHListNodeReverse(CDHList* plist);
void CDHListNodeClear(CDHList* plist);
void CDHListNodeDestroy(CDHList* plist);

CDHListNode* _BuyNodeCDHL(Elemtype val)
{
	CDHListNode* s = (CDHListNode*)malloc(sizeof(CDHListNode));
	assert(s != NULL);
	s->data = val;
	s->next = s;
	s->prev = s;
	return s;
}

void CDHListNodeInit(CDHList* plist)
{
	plist->head = (CDHListNode*)malloc(sizeof(CDHListNode));
	assert(plist->head != NULL);
	plist->head->next = plist->head;
	plist->head->prev = plist->head;
}

void CreateCDHListNodeFront(CDHList* plist, Elemtype val)
{
	CDHListNode* s = _BuyNodeCDHL(val);
	s->next = plist->head->next;
	s->prev = plist->head;
	plist->head->next = s;
	s->next->prev = s;
}

void CreateCDHListNodeTail(CDHList* plist, Elemtype val)
{
	CDHListNode* s = _BuyNodeCDHL(val);
	CDHListNode* p = plist->head;
	while (p->next != plist->head)
		p = p->next;
	s->next = p->next;
	s->prev = p;
	p->next = s;
	s->next->prev = s;
}

void CDHListNodeShow(CDHList plist)
{
	CDHListNode* p = plist.head->next;
	while (p != plist.head)
	{
		printf("%d->", p->data);
		p = p->next;
	}
	printf("over.\n");
}

void CDHListNodePopFront(CDHList* plist)
{
	CDHListNode* p = plist->head->next;
	if (p == plist->head)
	{
		printf("����ֻ��ͷ���,ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		p->prev->next = p->next;
		p->next->prev = p->prev;
		free(p);
	}
}

void CDHListNodePopTail(CDHList* plist)
{
	CDHListNode* p = plist->head->next;
	if (p == plist->head)
	{
		printf("����ֻ��ͷ���,ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		while (p->next != plist->head)
			p = p->next;
		p->prev->next = p->next;
		p->next->prev = p->prev;
		free(p);
	}
}

CDHListNode* CDHListNodeFind(CDHList pl, Elemtype val)
{
	CDHListNode* p = pl.head->next;
	if (p == pl.head)
	{
		return NULL;
	}
	else
	{
		while (p != pl.head && p->data != val)
			p = p->next;
		if (p == pl.head)
			return NULL;
		else
			return p;
	}
}

void CDHListNodeSort(CDHList* plist)
{
	CDHListNode* p = NULL;
	CDHListNode* q = NULL;
	CDHListNode* s = NULL;
	if (plist->head->next == plist->head || plist->head->next->next == plist->head)
		return;
	p = plist->head->next;
	q = p->next;
	q->prev = NULL;
	p->next = plist->head;
	while (q != plist->head)
	{
		if (q->data < plist->head->next->data)
		{
			s = q;
			q = q->next;
			q->prev = NULL;
			s->next = plist->head->next;
			s->prev = plist->head;
			plist->head->next = s;
			s->next->prev = s;

			p = plist->head->next;
			s = NULL;
		}
		else
		{
			s = q;
			q = q->next;
			q->prev = NULL;
			while (p->next != plist->head && s->data >= p->next->data)
				p = p->next;
			s->prev = p;
			s->next = p->next;
			p->next = s;
			s->next->prev = s;

			p = plist->head->next;
			s = NULL;
		}
	}
}

void CDHListNodeInsert(CDHList* plist, Elemtype val)
{
	CDHListNode* p = NULL;
	CDHListNode* s = _BuyNodeCDHL(val);
	CDHListNodeSort(&(*plist));
	if (plist->head->next == plist->head)
	{
		s->prev = plist->head;
		s->next = plist->head;
		plist->head->next = s;
		plist->head->prev = s;
	}
	else
	{
		p = plist->head->next;
		if (s->data < p->data)
		{
			s->next = p;
			s->prev = plist->head;
			plist->head->next = s;
			s->next->prev = s;

			p = plist->head->next;
			s = NULL;
		}
		else
		{
			while (p->next != plist->head && s->data >= p->next->data)
				p = p->next;
			s->next = p->next;
			s->prev = p;
			p->next = s;
			s->next->prev = s;

			p = plist->head->next;
			s = NULL;
		}
	}
}

void CDHListNodeErase(CDHList* plist, Elemtype val)
{
	CDHListNode* p = plist->head->next;
	CDHListNode* q = NULL;
	if (p == plist->head)
	{
		printf("����ֻ��ͷ���,ɾ��ʧ��!\n");
		return;
	}
	else
	{
		while (p != plist->head && p->data != val)
			p = p->next;
		if (p == plist->head)
		{
			printf("%d���ڸ������У�ɾ��ʧ�ܣ�\n", val);
			return;
		}
		else
		{
			p->prev->next = p->next;
			p->next->prev = p->prev;
			free(p);
		}
	}
}
void CDHListNodeReverse(CDHList* plist)
{
	CDHListNode* p = NULL;
	CDHListNode* q = NULL;
	CDHListNode* s = NULL;
	if (plist->head->next == plist->head || plist->head->next->next == plist->head)
		return;
	p = plist->head->next;//p����ֻ������λ��һ�����
	q = p->next;
	q->prev = NULL;
	p->next = plist->head;
	while (q != plist->head)
	{
		s = q;
		q = q->next;
		q->prev = NULL;
		s->next = plist->head->next;
		s->prev = plist->head;
		plist->head->next = s;
		s->next->prev = s;
	}
}

void CDHListNodeClear(CDHList* plist)
{
	CDHListNode* p = plist->head->next;
	CDHListNode* q = NULL;
	if (p == plist->head)
		return;
	else
	{
		while (p != plist->head)
		{
			q = p;
			p = p->next;
			p->prev = plist->head;
			plist->head->next = p;
			free(q);
		}
	}
}

void CDHListNodeDestroy(CDHList* plist)
{
	CDHListNodeClear(&(*plist));
	free(plist->head);
}