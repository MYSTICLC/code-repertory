#pragma once
#include"Common.h"
#define Elemtype int

typedef struct CDListNode
{
	Elemtype data;
	struct CDListNode* prev;
	struct CDListNode* next;
}CDListNode;

typedef CDListNode* CDList;

CDListNode* _BuyNodeCDL(Elemtype val);
void CDListNodeInit(CDList* plist);
void CreateCDListNodeFront(CDList* plist, Elemtype val);
void CreateCDListNodeTail(CDList* plist, Elemtype val);
void CDListNodeShow(CDList plist);
void CDListNodePopFront(CDList* plist);
void CDListNodePopTail(CDList* plist);
CDListNode* CDListNodeFind(CDList pl, Elemtype val);
void CDListNodeSort(CDList* plist);
void CDListNodeInsert(CDList* plist, Elemtype val);
void CDListNodeErase(CDList* plist, Elemtype val);
void CDListNodeReverse(CDList* plist);
void CDListNodeClear(CDList* plist);
void CDListNodeDestroy(CDList* plist);

CDListNode* _BuyNodeCDL(Elemtype val)
{
	CDListNode* s = (CDListNode*)malloc(sizeof(CDListNode));
	assert(s != NULL);
	s->data = val;
	s->prev = s;
	s->next = s;
	return s;
}

void CDListNodeInit(CDList* plist)
{
	*plist = NULL;
}

void CreateCDListNodeFront(CDList* plist, Elemtype val)
{
	CDListNode* s = _BuyNodeCDL(val);
	CDListNode* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		if ((*plist)->next == *plist)//���ֻ��һ�����
		{
			s->next = *plist;
			s->prev = *plist;
			(*plist)->prev = s;
			(*plist)->next = s;

			*plist = s;
		}
		else
		{
			while (p->next != *plist)
				p = p->next;
			s->next = *plist;
			s->prev = p;
			(*plist)->prev = s;
			p->next = s;

			*plist = s;
			p = *plist;
		}
	}
}

void CreateCDListNodeTail(CDList* plist, Elemtype val)
{
	CDListNode* s = _BuyNodeCDL(val);
	CDListNode* p = *plist;
	if (*plist == NULL)
		*plist = s;
	else
	{
		while (p->next != *plist)
			p = p->next;
		p->next = s;
		(*plist)->prev = s;
		s->next = *plist;
		s->prev = p;
	}
}

void CDListNodeShow(CDList plist)
{
	CDListNode* p = plist;
	if (p != NULL)
	{
		while (p->next != plist)
		{
			printf("%d->", p->data);
			p = p->next;
		}
		printf("%d->", p->data);
	}
	printf("over.\n");
}

void CDListNodePopFront(CDList* plist)
{
	CDListNode* p = *plist;
	CDListNode* s = NULL;
	if (*plist == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ��!\n");
		return;
	}
	else
	{
		if (p->next == *plist)//ֻ��һ�����
		{
			*plist = NULL;
			free(s);
		}
		else
		{
			s = p;
			while (p->next != *plist)
				p = p->next;
			*plist = (*plist)->next;
			p->next = *plist;
			(*plist)->prev = p;
			free(s);

			p = *plist;
			s = NULL;
		}
	}
}

void CDListNodePopTail(CDList* plist)
{
	CDListNode* p = *plist;
	CDListNode* prev = NULL;
	if (*plist == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ��!\n");
		return;
	}
	else
	{
		if (p->next == *plist)
		{
			*plist = NULL;
		}
		else//������㼰����
		{
			while (p->next != *plist)
			{
				prev = p;
				p = p->next;
			}
			prev->next = *plist;
			(*plist)->prev = prev;
		}
		free(p);
	}
}

CDListNode* CDListNodeFind(CDList pl, Elemtype val)
{
	CDListNode* p = pl;
	if (pl == NULL)
	{
		printf("����Ϊ�գ�����ʧ�ܣ�\n");
		return NULL;
	}
	else
	{
		while (p->next != pl && p->data != val)
			p = p->next;
		if (p->next == pl)
		{
			if (p->data == val)
				return p;
			else
				return NULL;
		}
		else
			return p;
	}
}

void CDListNodeSort(CDList* plist)//7 2 6 3 4 8 1   1 8 4 3 6 2 7
{
	CDListNode* p = NULL;
	CDListNode* q = NULL;
	CDListNode* s = NULL;
	if (*plist == NULL || (*plist)->next == (*plist))
		return;
	p = *plist;
	q = p->next;
	q->prev = NULL;
	while (q->next != *plist)
		q = q->next;
	q->next = NULL;
	q = p->next;
	p->prev = p;
	p->next = p;
	while (q!= NULL)
	{
		if (q->data < (*plist)->data)
		{
			while (p->next != *plist)
				p = p->next;
			s = q;
			q = q->next;
			if (q != NULL)
				q->prev = NULL;
			s->next = *plist;
			s->prev = p;
			(*plist)->prev = s;
			p->next = s;

			*plist = s;
			p = *plist;
			s = NULL;
		}
		else
		{
			s = q;
			q = q->next;
			if(q!=NULL)
				q->prev = NULL;
			while (p->next != *plist && s->data >= p->next->data)
			{
				p = p->next;
			}
			if (p->next == *plist)
			{
				s->next = *plist;
				s->prev = p;
				p->next = s;
				(*plist)->prev = s;
			}
			else
			{
				s->prev = p;
				s->next = p->next;
				p->next = s;
				s->next->prev = s;
			}
			p = *plist;
		}
	}
}

void CDListNodeInsert(CDList* plist, Elemtype val)
{
	CDListNode* s = _BuyNodeCDL(val);
	CDListNode* p = NULL;
	CDListNodeSort(&(*plist));
	if (*plist == NULL)
	{
		*plist = s;
	}
	else
	{
		p = *plist;
		if (s->data < (*plist)->data)
		{
			while (p->next != *plist)
				p = p->next;
			s->next = *plist;
			s->prev = p;
			p->next = s;
			(*plist)->prev = s;

			*plist = s;
			p = *plist;
		}
		else
		{
			while (p->next != *plist && s->data >= p->next->data)
				p = p->next;
			if (p->next == *plist)
			{
				s->prev = p;
				s->next = *plist;
				p->next = s;
				(*plist)->prev = s;
			}
			else
			{
				s->prev = p;
				s->next = p->next;
				p->next = s;
				s->next->prev = s;
			}
		}
	}
}

void CDListNodeErase(CDList* plist, Elemtype val)
{
	CDListNode* p = *plist;
	CDListNode* s = NULL;
	if (*plist == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ�ܣ�\n");
		return;
	}
	while (p->next != *plist && p->data != val)
		p = p->next;
	if (p == *plist && p->next == *plist)
	{
		*plist = NULL;
		free(p);
	}
	else if (p == *plist && p->next != *plist)
	{
		s = p;
		while (p->next != *plist)
			p = p->next;
		*plist = (*plist)->next;
		p->next = *plist;
		(*plist)->prev = p;

		p = *plist;
		free(s);
	}
	else
	{
		if (p->next == *plist)
		{
			if (p->data != val)
			{
				printf("%d���ڸ������У�ɾ��ʧ�ܣ�\n", val);
				return;
			}
			else
			{
				p->prev->next = p->next;
				p->next->prev = p->prev;
				free(p);
			}
		}
		else
		{
			p->prev->next = p->next;
			p->next->prev = p->prev;
			free(p);
		}
	}
}

void CDListNodeReverse(CDList* plist)
{
	CDListNode* p = NULL;
	CDListNode* q = NULL;
	CDListNode* s = NULL;
	if (*plist == NULL || (*plist)->next == (*plist))
		return;
	p = *plist;
	q = p->next;
	q->prev = NULL;
	while (q->next != *plist)
		q = q->next;
	q->next = NULL;
	q = p->next;
	p->prev = p;
	p->next = p;
	while (q!= NULL)
	{
		while (p->next != *plist)
			p = p->next;
		s = q;
		q = q->next;
		if (q != NULL)
			q->prev = NULL;
		s->prev = p;
		s->next = *plist;
		p->next = s;
		(*plist)->prev = s;

		*plist = s;
		p = *plist;
		s = NULL;
	}
}

void CDListNodeClear(CDList* plist)
{
	CDListNode* p = *plist;
	CDListNode* s = NULL;
	if (*plist == NULL)
		return;
	else
	{
		while (*plist != NULL)
		{
			if ((*plist)->next = *plist)
			{
				*plist = NULL;
				free(p);
			}
			else
			{
				while (p->next != *plist)
					p = p->next;
				s = *plist;
				*plist = (*plist)->next;
				(*plist)->prev = p;
				p->next = *plist;

				p = *plist;
				free(s);
			}
		}
	}
}

void CDListNodeDestroy(CDList* plist)
{
	CDListNodeClear(&(*plist));
}
