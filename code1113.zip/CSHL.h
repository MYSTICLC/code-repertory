#pragma once
#include"Common.h"
#define Elemtype int

typedef struct CHSListNode
{
	Elemtype data;
	struct CHSListNode* next;
}CHSListNode;

typedef struct CHSList
{
	struct CHSListNode* head;
}CHSList;

CHSListNode* _BuyNodeCHSL(Elemtype val);
void CHSListNodeInit(CHSList* plist);
void CreateCHSListNodeFront(CHSList* plist, Elemtype val);
void CreateCHSListNodeTail(CHSList* plist, Elemtype val);
void CHSListNodeShow(CHSList plist);
void CHSListNodePopFront(CHSList* plist);
void CHSListNodePopTail(CHSList* plist);
CHSListNode* CHSListNodeFind(CHSList pl, Elemtype val);
void CHSListNodeSort(CHSList* plist);
void CHSListNodeInsert(CHSList* plist, Elemtype val);
void CHSListNodeErase(CHSList* plist, Elemtype val);
void CHSListNodeReverse(CHSList* plist);
void CHSListNodeClear(CHSList* plist);
void CHSListNodeDestroy(CHSList* plist);

CHSListNode* _BuyNodeCHSL(Elemtype val)
{
	CHSListNode* s = (CHSListNode*)malloc(sizeof(CHSListNode));
	assert(s != NULL);
	s->data = val;
	s->next = s;
	return s;
}

void CHSListNodeInit(CHSList* plist)
{
	plist->head = (CHSListNode*)malloc(sizeof(CHSListNode));
	assert(plist->head != NULL);
	plist->head->next = plist->head;
}

void CreateCHSListNodeFront(CHSList* plist, Elemtype val)
{
	CHSListNode* s = _BuyNodeCHSL(val);
	CHSListNode* p = plist->head;
	if (plist->head->next == plist->head)//ֻ��ͷ���
	{
		plist->head->next = s;
		s->next = plist->head;
	}
	else
	{
		s->next = plist->head->next;
		plist->head->next = s;
	}
}

void CreateCHSListNodeTail(CHSList * plist, Elemtype val)
{
	CHSListNode* s = _BuyNodeCHSL(val);
	CHSListNode* p = plist->head;
	if (plist->head->next == plist->head)
	{
		plist->head->next = s;
		s->next = plist->head;
	}
	else
	{
		while (p->next != plist->head)
			p = p->next;
		p->next = s;
		s->next = plist->head;
	}
}

void CHSListNodeShow(CHSList plist)
{
	CHSListNode* p = plist.head;
	if (p->next != plist.head)
	{
		p = p->next;
		while (p!= plist.head)
		{
			printf("%d->", p->data);
			p = p->next;
		}
	}
	printf("over.\n");
}
void CHSListNodePopFront(CHSList* plist)
{
	CHSListNode* p = plist->head;
	if (p->next == plist->head)
	{
		printf("����ֻ��ͷ��㣬ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		p = p->next;
		plist->head->next = p->next;
		free(p);
	}
}
void CHSListNodePopTail(CHSList* plist)
{
	CHSListNode* p = plist->head;
	CHSListNode* prev = NULL;
	if (p->next == plist->head)
	{
		printf("����ֻ��ͷ��㣬ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		prev = plist->head;
		while (p->next != plist->head)
		{
			prev = p;
			p = p->next;
		}
		prev->next = plist->head;
		free(p);
	}
}

CHSListNode* CHSListNodeFind(CHSList pl, Elemtype val)
{
	CHSListNode* p = pl.head;
	if (pl.head->next == pl.head)
	{
		printf("����ֻ��ͷ��㣬����ʧ�ܣ�\n");
		return NULL;
	}
	else
	{
		p = p->next;
		while (p != pl.head && p->data != val)
			p = p->next;
		if (p == pl.head)
			return NULL;
		else
			return p;
	}
}

void CHSListNodeSort(CHSList* plist)
{
	CHSListNode* p = NULL;
	CHSListNode* q = NULL;
	CHSListNode* s = NULL;
	if (plist->head->next == plist->head || plist->head->next->next == plist->head)
		return;
	p = plist->head->next;
	q = p->next;
	p->next = plist->head;
	while (q != plist->head)
	{
		if (q->data < plist->head->next->data)
		{
			s = q;
			q = q->next;
			s->next = plist->head->next;
			plist->head->next = s;
		}
		else
		{
			s = q;
			q = q->next;
			while (p->next != plist->head && s->data >= p->next->data)
				p = p->next;
			if (p->next == plist->head)
			{
				p->next = s;
				s->next = plist->head;
			}
			else
			{
				s->next = p->next;
				p->next = s;
			}
		}
		p = plist->head->next;
	}
}

void CHSListNodeInsert(CHSList* plist, Elemtype val)
{
	CHSListNode* p = NULL;
	CHSListNode* s = _BuyNodeCHSL(val);
	CHSListNodeSort(&(*plist));
	if (plist->head->next == plist->head)
	{
		plist->head->next = s;
		s->next = plist->head;
	}
	else
	{
		p = plist->head->next;
		if (s->data < p->data)
		{
			s->next = p;
			plist->head->next = s;
		}
		else
		{
			while (p->next != plist->head && s->data >= p->next->data)
				p = p->next;
			if (p->next == plist->head)
			{
				p->next = s;
				s->next = plist->head;
			}
			else
			{
				s->next = p->next;
				p->next = s;
			}
		}
	}
}

void CHSListNodeErase(CHSList* plist, Elemtype val)
{
	CHSListNode* p = plist->head->next;
	CHSListNode* prev = plist->head;
	if (p == plist->head)//����ֻ��ͷ���
	{
		printf("����ֻ��ͷ���,ɾ��ʧ�ܣ�\n");
		return;
	}
	else
	{
		while (p != plist->head && p->data != val)
		{
			prev = p;
			p = p->next;
		}
		if (p == plist->head)
		{
			printf("%d���������У�ɾ��ʧ�ܣ�\n", val);
			return;
		}
		else
		{
			prev->next = p->next;
			free(p);
		}
	}
}

void CHSListNodeReverse(CHSList* plist)
{
	CHSListNode* p = NULL;
	CHSListNode* q = NULL;
	CHSListNode* s = NULL;
	if (plist->head->next == plist->head || plist->head->next->next == plist->head)
		return;
	else
	{
		p = plist->head->next;
		q = p->next;
		p->next = plist->head;
		while (q != plist->head)
		{
			s = q;
			q = q->next;
			s->next = p;
			plist->head->next = s;

			p = plist->head->next;
		}
	}
}

void CHSListNodeClear(CHSList* plist)
{
	CHSListNode* p = plist->head->next;
	CHSListNode* s = NULL;
	if (p == plist->head)
		return;
	while (p != plist->head)
	{
		s = p;
		p = p->next;
		free(s);
	}
	plist->head->next = plist->head;
}

void CHSListNodeDestroy(CHSList* plist)
{
	CHSListNodeClear(&(*plist));
	free(plist->head);
}