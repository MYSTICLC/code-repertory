#define _CRT_SECURE_NO_WARNINGS
#include "LL.h"
#include "LLNH.h"
#include "DL.h"
#include "DLH.h"
#include "CSL.h"
#include "CSHL.h"
#include "CDL.h"
#include "CDHL.h"

int main(void)
{
	//List mylist;
	//InitList(&mylist);

	//SListNH mylist;
	//SLNHInit(&mylist);
	
	//DList mylist;
	//DListNodeInit(&mylist);

	//DHList mylist;
	//DHListNodeInit(&mylist);

	//CSList mylist;
	//CSListNodeInit(&mylist);

	//CHSList mylist;
	//CHSListNodeInit(&mylist);

	//CDList mylist;
	//CDListNodeInit(&mylist);

	CDHList mylist;
	CDHListNodeInit(&mylist);
	

	Elemtype val=0;
	//ListNode* p;
	//ListNodeNH * p
	//DListNode* p;
	//DHListNode* p;
	//CSListNode* p;
	//CHSListNode* p;
	//CDListNode* p;
	CDHListNode* p;

	int select = 1;
	while (select)
	{
		printf("********************************************\n");
		printf("* [1] push_front          [2] push_tail    *\n");
		printf("* [3] pop_front           [4] pop_tail     *\n");
		printf("* [5] clear               [6] find_val     *\n");
		printf("* [7] insert              [8] erease       *\n");
		printf("* [9] destroy             [10]show         *\n");
		printf("* [11]sort                [12]reverse      *\n");
		printf("* [0]quit_system                           *\n");
		printf("********************************************\n");
		printf("��������Ҫ���еĲ�����ѡ��: ");
		scanf("%d", &select);
		if (select == 0)
		{
			break;
		}
		switch (select)
		{
		case 1://����scanf��whileѭ�����иĽ�����������Ҳ��Ҫ�����ʵ��޸�
			while (scanf("%d", &val), val != -9999)
			{
				//CreateListFront(&mylist, val);
				//CreateSLNHFront(&mylist,val);
				//CreateDListNodeFront(&mylist, val);
				//CreateDHListNodeFront(&mylist, val);
				//CreateCSListNodeFront(&mylist, val);
				//CreateCHSListNodeFront(&mylist, val);
				//CreateCDListNodeFront(&mylist, val);
				CreateCDHListNodeFront(&mylist, val);
			}
			break;
		case 2:
			while (scanf("%d", &val), val != -9999)
			{
				//CreateListTail(&mylist, val);
				//CreateSLNHTail(&mylist, val);
				//CreateDListNodeTail(&mylist, val);
				//CreateDHListNodeTail(&mylist, val);
				//CreateCSListNodeTail(&mylist, val);
				//CreateCHSListNodeTail(&mylist, val);
				//CreateCDListNodeTail(&mylist, val);
				CreateCDHListNodeTail(&mylist, val);
			}
			break;
		case 3:
			//ListPopFront(&mylist);
			//SLNHPopFront(&mylist);
			//DListNodePopFront(&mylist);
			//DHListNodePopFront(&mylist);
			//CSListNodePopFront(&mylist);
			//CHSListNodePopFront(&mylist);
			//CDListNodePopFront(&mylist);
			CDHListNodePopFront(&mylist);
			break;
		case 4:
			//ListPopTail(&mylist);
			//SLNHPopTail(&mylist);
			//DListNodePopTail(&mylist);
			//DHListNodePopTail(&mylist);
			//CSListNodePopTail(&mylist);
			//CHSListNodePopTail(&mylist);
			//CDListNodePopTail(&mylist);
			CDHListNodePopTail(&mylist);
			break;
		case 5:
			//SLNHClear(&mylist);
			//DListNodeClear(&mylist);
			//DHListNodeClear(&mylist);
			//CSListNodeClear(&mylist);
			//CHSListNodeClear(&mylist);
			//CDListNodeClear(&mylist);
			CDHListNodeClear(&mylist);
			break;
		case 6:
			printf("��������Ҫ���ҵ�ֵ:");
			scanf("%d", &val);
			//p = ListFindByVal(mylist, val);
			//p = SLNHFind(mylist, val);
			//p = DListNodeFind(mylist, val);
			//p = DHListNodeFind(mylist, val);
			//p = CSListNodeFind(mylist, val);
			//p = CHSListNodeFind(mylist, val);
			//p = CDListNodeFind(mylist, val);
			p = CDHListNodeFind(mylist, val);
			if (p != NULL)
			{
				printf("���ҳɹ�,%d�ڸ�������!\n", val);
			}
			else
			{
				printf("����ʧ�ܣ�%d���ڸ�������!\n", val);
			}
			break;
		case 7:
			printf("������Ҫ����Ľ���ֵ:");
			scanf("%d",&val);
			//ListInsertAfter(mylist, pos, val);
			//SLNHInsert(&mylist, val);
			//DListNodeInsert(&mylist, val);
			//DHListNodeInsert(&mylist, val);
			//CSListNodeInsert(&mylist, val);
			//CHSListNodeInsert(&mylist, val);
			//CDListNodeInsert(&mylist, val);
			CDHListNodeInsert(&mylist, val);
			break;
		case 8:
			printf("������Ҫɾ���Ľ���ֵ:");
			scanf("%d",&val);
			//ListErase(mylist, val);
			//SLNHErase(&mylist, val);
			//DListNodeErase(&mylist, val);
			//DHListNodeErase(&mylist, val);
			//CSListNodeErase(&mylist, val);
			//CHSListNodeErase(&mylist, val);
			//CDListNodeErase(&mylist, val);
			CDHListNodeErase(&mylist, val);
			break;
		case 9:
			//ListDestroy(&mylist);
			//SLNHDestroy(&mylist);
			//DListNodeDestroy(&mylist);
			//DHListNodeDestroy(&mylist);
			//CSListNodeDestroy(&mylist);
			//CHSListNodeDestroy(&mylist);
			//CDListNodeDestroy(&mylist);
			CDHListNodeDestroy(&mylist);
			break;
		case 10:
			//ListShow(mylist);
			//SLNHShow(mylist);
			//DListNodeShow(mylist);
			//DHListNodeShow(mylist);
			//CSListNodeShow(mylist);
			//CHSListNodeShow(mylist);
			//CDListNodeShow(mylist);
			CDHListNodeShow(mylist);
			break;
		case 11:
			//ListSort(&mylist);
			//SLNHSort(&mylist);
			//DListNodeSort(&mylist);
			//DHListNodeSort(&mylist);
			//CSListNodeSort(&mylist);
			//CHSListNodeSort(&mylist);
			//CDListNodeSort(&mylist);
			CDHListNodeSort(&mylist);
			break;
		case 12:
			//ListReverse(&mylist);
			//SLNHReverse(&mylist);
			//DListNodeReverse(&mylist);
			//DHListNodeReverse(&mylist);
			//CSListNodeReverse(&mylist);
			//CHSListNodeReverse(&mylist);
			//CDListNodeReverse(&mylist);
			CDHListNodeReverse(&mylist);
			break;
		default:
			break;
		}
	}
}		
